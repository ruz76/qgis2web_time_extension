var baseLayer = new ol.layer.Group({
    'title': '',
    layers: [
new ol.layer.Tile({
    'title': 'OSM',
    'type': 'base',
    source: new ol.source.OSM()
})
]
});
var format_syracuse0 = new ol.format.GeoJSON();
var features_syracuse0 = format_syracuse0.readFeatures(json_syracuse0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_syracuse0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_syracuse0.addFeatures(features_syracuse0);var lyr_syracuse0 = new ol.layer.Vector({
                source:jsonSource_syracuse0, 
                style: style_syracuse0,
                title: '<img src="styles/legend/syracuse0.png" /> syracuse'
            });

lyr_syracuse0.setVisible(true);
var layersList = [baseLayer,lyr_syracuse0];
lyr_syracuse0.set('fieldAliases', {'long': 'long', 'lat': 'lat', 'long, lat': 'long, lat', 'site_no': 'site_no', 'site_nm': 'site_nm', 'date': 'date', 'Q': 'Q', 'Q_m': 'Q_m', 'GW': 'GW', 'GW_m': 'GW_m', 'PDSI': 'PDSI', 'PUMP': 'PUMP', 'PUMP_m': 'PUMP_m', 'charts': 'charts', 'date_intst': 'date_intst', 'date_int2': 'date_int2', });
lyr_syracuse0.set('fieldImages', {'long': 'TextEdit', 'lat': 'TextEdit', 'long, lat': 'TextEdit', 'site_no': 'TextEdit', 'site_nm': 'TextEdit', 'date': 'TextEdit', 'Q': 'TextEdit', 'Q_m': 'TextEdit', 'GW': 'TextEdit', 'GW_m': 'TextEdit', 'PDSI': 'TextEdit', 'PUMP': 'TextEdit', 'PUMP_m': 'TextEdit', 'charts': 'TextEdit', 'date_intst': 'TextEdit', 'date_int2': 'TextEdit', });
lyr_syracuse0.set('fieldLabels', {'long': 'no label', 'lat': 'no label', 'long, lat': 'no label', 'site_no': 'no label', 'site_nm': 'no label', 'date': 'no label', 'Q': 'no label', 'Q_m': 'no label', 'GW': 'no label', 'GW_m': 'no label', 'PDSI': 'no label', 'PUMP': 'no label', 'PUMP_m': 'no label', 'charts': 'no label', 'date_intst': 'no label', 'date_int2': 'no label', });
lyr_syracuse0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});