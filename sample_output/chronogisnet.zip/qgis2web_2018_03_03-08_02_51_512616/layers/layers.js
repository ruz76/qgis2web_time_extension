var wms_layers = [];
var format_test_chronosignet_0 = new ol.format.GeoJSON();
var features_test_chronosignet_0 = format_test_chronosignet_0.readFeatures(json_test_chronosignet_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_test_chronosignet_0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_test_chronosignet_0.addFeatures(features_test_chronosignet_0);var lyr_test_chronosignet_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_test_chronosignet_0, 
                style: style_test_chronosignet_0,
                title: '<img src="styles/legend/test_chronosignet_0.png" /> test_chronosignet'
            });

lyr_test_chronosignet_0.setVisible(true);
var layersList = [lyr_test_chronosignet_0];
lyr_test_chronosignet_0.set('fieldAliases', {'id': 'id', 'NOM': 'NOM', 'DEBUT': 'DEBUT', 'FIN': 'FIN', 'DEB': 'DEB', 'END': 'END', 'START': 'START', 'STOP': 'STOP', 'DEB_S': 'DEB_S', 'FIN_S': 'FIN_S', });
lyr_test_chronosignet_0.set('fieldImages', {'id': 'TextEdit', 'NOM': 'TextEdit', 'DEBUT': 'TextEdit', 'FIN': 'TextEdit', 'DEB': 'TextEdit', 'END': 'TextEdit', 'START': 'TextEdit', 'STOP': 'TextEdit', 'DEB_S': 'TextEdit', 'FIN_S': 'TextEdit', });
lyr_test_chronosignet_0.set('fieldLabels', {'id': 'no label', 'NOM': 'no label', 'DEBUT': 'no label', 'FIN': 'no label', 'DEB': 'no label', 'END': 'no label', 'START': 'no label', 'STOP': 'no label', 'DEB_S': 'no label', 'FIN_S': 'no label', });
lyr_test_chronosignet_0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});